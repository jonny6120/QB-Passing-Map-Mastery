
import React, { useState } from "react";
import FootballFieldDetailed from "./FootballFieldDetailed";

const defaultForm = {
  x: "", y: "", result: "", quarter: "", down: "", distance: "",
  hash: "", week: "", receiver: "", redzone: false, team: "", direction: "", };
const defaultFilter = {
  result: "", quarter: "", down: "", hash: "", redzone: "",
  week: "", receiver: "", team: "", direction: "", };

export default function App() {
  const [passes, setPasses]   = useState([]);
  const [form, setForm]       = useState(defaultForm);
  const [editIdx, setEdit]    = useState(null);
  const [filter, setFilter]   = useState(defaultFilter);
  const [hoverXY, setHoverXY] = useState(null);

  const initials = r => r ? r.trim().split(" ").map(w => w[0]).join("").toUpperCase() : "";

  function save() {
    if (form.x === "" || form.y === "" || form.result === "") return;
    const obj = { ...form, x: +form.x, y: +form.y };
    if (editIdx !== null) {
      const cp = [...passes]; cp[editIdx] = obj; setPasses(cp); setEdit(null);
    } else { setPasses([...passes, obj]); }
    setForm(defaultForm);
  }
  const startEdit = i => { setEdit(i); setForm(passes[i]); };
  const del = i => { const cp = [...passes]; cp.splice(i,1); setPasses(cp); if(editIdx===i){setEdit(null); setForm(defaultForm);} };

  const match = p =>
    (!filter.result   || p.result === filter.result) &&
    (!filter.quarter  || p.quarter === filter.quarter) &&
    (!filter.down     || p.down === filter.down) &&
    (!filter.hash     || p.hash === filter.hash) &&
    (!filter.redzone  || (filter.redzone === "Yes") === p.redzone) &&
    (!filter.week     || p.week === filter.week) &&
    (!filter.receiver || p.receiver.toLowerCase().includes(filter.receiver.toLowerCase())) &&
    (!filter.team     || p.team.toLowerCase().includes(filter.team.toLowerCase())) &&
    (!filter.direction || p.direction === filter.direction);

  const shown = passes.map((p,i)=>({...p,i})).filter(match);

  const box={padding:4,height:32}; const num={...box,width:70}; const sel={...box,width:95};

  return (
    <div style={{ padding:16, background:"#111", color:"#fff", minHeight:"100vh", fontFamily:"sans-serif" }}>
      <h1>QB Passing Map – Hover XY</h1>

      {/* Form */}
      <div style={{ display:"flex", flexWrap:"wrap", gap:8, marginBottom:12 }}>
        <input style={num} placeholder="X" value={form.x} onChange={e=>setForm({...form,x:e.target.value})}/>
        <input style={num} placeholder="Y" value={form.y} onChange={e=>setForm({...form,y:e.target.value})}/>
        <select style={sel} value={form.result} onChange={e=>setForm({...form,result:e.target.value})}>
          <option value="">Result</option><option>Completion</option><option>Incompletion</option><option>Interception</option>
        </select>
        <select style={sel} value={form.quarter} onChange={e=>setForm({...form,quarter:e.target.value})}>
          <option value="">Quarter</option>{["1","2","3","4","OT"].map(q=><option key={q}>{q}</option>)}
        </select>
        <select style={sel} value={form.down} onChange={e=>setForm({...form,down:e.target.value})}>
          <option value="">Down</option>{["1","2","3","4"].map(d=><option key={d}>{d}</option>)}
        </select>
        <input style={num} placeholder="Distance" value={form.distance} onChange={e=>setForm({...form,distance:e.target.value})}/>
        <select style={sel} value={form.hash} onChange={e=>setForm({...form,hash:e.target.value})}>
          <option value="">Hash</option>{["Left","Middle","Right"].map(h=><option key={h}>{h}</option>)}
        </select>
        
        <select style={sel} value={form.direction} onChange={e=>setForm({...form, direction: e.target.value})}>
          <option value="">Direction</option><option>Going In</option><option>Going Out</option>
        </select>
        <input style={{...num,width:60}} placeholder="Week" value={form.week} onChange={e=>setForm({...form,week:e.target.value})}/>
        <input style={{...box,width:120}} placeholder="Receiver" value={form.receiver} onChange={e=>setForm({...form,receiver:e.target.value})}/>
        <label style={{display:"flex",alignItems:"center",gap:4}}>
          <input type="checkbox" checked={form.redzone} onChange={e=>setForm({...form,redzone:e.target.checked})}/>Red Zone
        </label>
        <input style={{...box,width:100}} placeholder="Team" value={form.team} onChange={e=>setForm({...form,team:e.target.value})}/>
        <button onClick={save}>{editIdx!==null?"Update":"Add"} Pass</button>
        {editIdx!==null && <button onClick={()=>{setEdit(null); setForm(defaultForm);}}>Cancel</button>}
      </div>

      {/* Filters */}
      <div style={{ display:"flex", flexWrap:"wrap", gap:8, marginBottom:12 }}>
        <select style={sel} value={filter.result} onChange={e=>setFilter({...filter,result:e.target.value})}>
          <option value="">Result</option><option>Completion</option><option>Incompletion</option><option>Interception</option>
        </select>
        <select style={sel} value={filter.quarter} onChange={e=>setFilter({...filter,quarter:e.target.value})}>
          <option value="">Quarter</option>{["1","2","3","4","OT"].map(q=><option key={q}>{q}</option>)}
        </select>
        <select style={sel} value={filter.down} onChange={e=>setFilter({...filter,down:e.target.value})}>
          <option value="">Down</option>{["1","2","3","4"].map(d=><option key={d}>{d}</option>)}
        </select>
        <select style={sel} value={filter.hash} onChange={e=>setFilter({...filter,hash:e.target.value})}>
          <option value="">Hash</option>{["Left","Middle","Right"].map(h=><option key={h}>{h}</option>)}
        </select>
        
      <select style={sel} value={filter.direction} onChange={e=>setFilter({...filter, direction: e.target.value})}>
        <option value="">Direction</option><option>Going In</option><option>Going Out</option>
      </select>
      <select style={sel} value={filter.redzone} onChange={e=>setFilter({...filter,redzone:e.target.value})}>
          <option value="">Red Zone</option><option>Yes</option><option>No</option>
        </select>
        <input style={num} placeholder="Week" value={filter.week} onChange={e=>setFilter({...filter,week:e.target.value})}/>
        <input style={{...box,width:120}} placeholder="Receiver" value={filter.receiver} onChange={e=>setFilter({...filter,receiver:e.target.value})}/>
        <input style={{...box,width:100}} placeholder="Team" value={filter.team} onChange={e=>setFilter({...filter,team:e.target.value})}/>
        <button onClick={()=>setFilter(defaultFilter)}>Reset Filters</button>
      </div>

      {/* Field */}
      <div style={{position:"relative"}}
           onMouseMove={e=>{
             const b=e.currentTarget.getBoundingClientRect();
             const relX=(e.clientX-b.left)/b.width;
             const yards=Math.round(((relX-0.0833)/0.8334)*100);
             const relY=Math.round(e.clientY-b.top);
             setHoverXY({x:yards,y:relY});
           }}
           onMouseLeave={()=>setHoverXY(null)}
      >
        <FootballFieldDetailed/>
        {shown.map(p=>(
          <div key={p.i} style={{position:"absolute",left:`calc(8.33% + ${(p.x/100)*83.34}%)`,
                top:p.y,transform:"translate(-50%,-50%)",textAlign:"center"}}>
            <div style={{fontSize:18,color:p.result==="Completion"?"lime":p.result==="Incompletion"?"yellow":"red"}}>
              {p.result==="Completion"?"✅":p.result==="Incompletion"?"❌":"⚠️"}
            </div>
            <div style={{fontSize:10}}>{initials(p.receiver)}</div>
          </div>
        ))}
        {hoverXY && (
          <div style={{position:"absolute",right:12,bottom:12,background:"#0008",padding:"4px 8px",
                       fontSize:12,borderRadius:4}}>
            X: {hoverXY.x}&nbsp; Y: {hoverXY.y}
          </div>
        )}
      </div>

      {/* Table */}
      <table style={{marginTop:20,width:"100%",borderCollapse:"collapse",fontSize:12}}>
        <thead><tr>{Object.keys(defaultForm).map(k=><th key={k} style={{border:"1px solid #555",padding:4}}>{k.toUpperCase()}</th>)}<th/></tr></thead>
        <tbody>{shown.map(p=>(
          <tr key={p.i}>
            {Object.keys(defaultForm).map(k=><td key={k} style={{border:"1px solid #333",padding:4}}>{p[k]?.toString()}</td>)}
            <td><button onClick={()=>startEdit(p.i)}>✏️</button>
                <button onClick={()=>del(p.i)}>🗑️</button></td>
          </tr>
        ))}</tbody>
      </table>
    </div>
  );
}
